<html>
<head>
<title>ChartDirector 6.0 Sample Programs</title>
</head>
<frameset rows="19,*" framespacing="0">
    <frame
        name="indextop"
        src="indextop.php"
        scrolling="no"
        frameborder="1"
    />
    <frameset cols="222,*" framespacing="0">
        <frame
            name="indexleft"
            src="indexleft.php"
            scrolling="auto"
            frameborder="1"
        />
        <frame
            name="indexright"
            src="indexright.php"
            scrolling="auto"
            frameborder="1"
        />
    </frameset>
</frameset>
</html>
